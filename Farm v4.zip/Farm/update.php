<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// get passed in info
$tag = $_POST["tagnumber"]; 
/**
$color = $_POST["color"];
$age = $_POST["age"];
$year = $_POST["purchasedyr"] ;

$calf = $_POST{"has_calf"};
$calfNumber = $_POST{"calf_num"};
**/
$cow = $_POST{"Ntype"};
//$Number_of_Calves = $_POST{"number_of_calves"} ;
$Ntag = $_POST["Ntagnumber"]; 
$Ncolor = $_POST["Ncolor"];
$Nage = $_POST["Nage"];
$Nyear = $_POST["Npurchasedyr"] ;
$Ncow = $_POST{"Ntype"};
$Ncalf = $_POST{"Nhas_calf"};
$NcalfNumber = $_POST{"Ncalf_num"};
$Ncalves = $_POST{"Nnumber_of_calves"} ;


//Gets farm selection
$selection = $_POST["farm#"];

switch($selection)  {
  case "FARM 1":
        echo "selection is farm 1!"; 
        
        switch ($cow) {
            case "COW":
// quires to update overall farm table
$sql = "UPDATE Farm1 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm1 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm1 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm1 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm1 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm1 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm1 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE cows SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE cows SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE cows SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE cows SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE cows SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE cows SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE cows SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE cows SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE cows SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
            
            case "BULL":
// quires to update overall farm table
$sql = "UPDATE Farm1 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm1 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm1 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm1 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm1 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm1 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm1 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE bulls SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE bulls SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE bulls SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE bulls SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE bulls SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE bulls SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE bulls SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE bulls SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE bulls SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;


            case "CALF":
// quires to update overall farm table
$sql = "UPDATE Farm1 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm1 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm1 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm1 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm1 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm1 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm1 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE calves SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE calves SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE calves SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE calves SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE calves SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE calves SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE calves SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE calves SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE calves SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
           
   
                
} // TYPE switch case close
        break;
case "FARM 2":
        echo "selection is farm 2!"; 
   switch ($cow) {
            case "COW":
// quires to update overall farm table
$sql = "UPDATE Farm2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE cows2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE cows2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE cows2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE cows2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE cows2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE cows2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE cows2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE cows2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE cows2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
            
            case "BULL":
// quires to update overall farm table
$sql = "UPDATE Farm2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE bulls2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE bulls2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE bulls2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE bulls2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE bulls2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE bulls2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE bulls2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE bulls2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE bulls2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;


            case "CALF":
// quires to update overall farm table
$sql = "UPDATE Farm2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE calves2 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE calves2 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE calves2 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE calves2 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE calves2 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE calves2 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE calves2 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE calves2 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE calves2 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
           
   
                
} // TYPE switch case close
   break;
case "FARM 3":
        echo "selection is farm 3!";        
   switch ($cow) {
            case "COW":
// quires to update overall farm table
$sql = "UPDATE Farm3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE cows3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE cows3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE cows3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE cows3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE cows3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE cows3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE cows3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE cows3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE cows3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
            
            case "BULL":
// quires to update overall farm table
$sql = "UPDATE Farm3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE bulls3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE bulls3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE bulls3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE bulls3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE bulls3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE bulls3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE bulls3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE bulls3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE bulls3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;


            case "CALF":
// quires to update overall farm table
$sql = "UPDATE Farm3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE calves3 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE calves3 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE calves3 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE calves3 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE calves3 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE calves3 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE calves3 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE calves3 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE calves3 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
           
   
                
} // TYPE switch case close
   break;
        
case "FARM 4":
         switch ($cow) {
            case "COW":
// quires to update overall farm table
$sql = "UPDATE Farm4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE cows4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE cows4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE cows4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE cows4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE cows4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE cows4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE cows4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE cows4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE cows4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
            
            case "BULL":
// quires to update overall farm table
$sql = "UPDATE Farm4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE bulls4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE bulls4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE bulls4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE bulls4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE bulls4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE bulls4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE bulls4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE bulls4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE bulls4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;


            case "CALF":
// quires to update overall farm table
$sql = "UPDATE Farm4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
 // quires to update overall cow table   
$sql9 = "UPDATE calves4 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql10 = "UPDATE calves4 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql11 = "UPDATE calves4 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql12 = "UPDATE calves4 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql13 = "UPDATE calves4 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql14 = "UPDATE calves4 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql15 = "UPDATE calves4 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql16 = "UPDATE calves4 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql17 = "UPDATE calves4 SET number_of_calves = '$Ncalves'  WHERE tagnumber = '$tag'";
    if ($conn->query($sql) === TRUE) {
        $conn->query($sql1);
        $conn->query($sql2);
        $conn->query($sql3);
        $conn->query($sql4);
        $conn->query($sql5);
        $conn->query($sql6);
        $conn->query($sql7);
        $conn->query($sql8);
        $conn->query($sql9);
        $conn->query($sql10);
        $conn->query($sql11);
        $conn->query($sql12);
        $conn->query($sql13);
        $conn->query($sql14);
        $conn->query($sql15);
        $conn->query($sql16);
        $conn->query($sql17);
        
    echo "New record created successfully";
    //header("Location: home.php");
    } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
             }
        
            break;
           
   
                
} // TYPE switch case close
   break;
} // OVERALL farm switch case close

#header("Location: home.php");
$conn->close();



?>

<form action="home.php" method="POST">
    <button type="submit"> Home</button>
</form>