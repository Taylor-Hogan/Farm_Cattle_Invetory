
<?php
session_start();
include('dbcreds.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = ("SELECT * FROM Farm1");

$result = $conn->query($query);

?>
<html>
  <script>
            function showUser(str) {
                if (str == "") {
                    document.getElementById("txtHint").innerHTML = "";
                    return;
                } else {
                    if (window.XMLHttpRequest) {
                        // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (this.readyState == 4 && this.status == 200) {
                            document.getElementById("txtHint").innerHTML = this.responseText;
                        }
                    };
                    xmlhttp.open("GET", "getuser.php?q=" + str, true);
                    xmlhttp.send();
                }
            }
        </script>  
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>  
<body>

<Center>
   <H1>Hogan's Farm Database</H1> 
    <table>
  <tr>
    <th>Add a Record</th>
    <th>Update a Record</th>
    <th>Delte a Record</th>
  </tr>
  <tr>
    <td><form action="get_info.php" method="POST">
<button type="submit"> ADD</button>
</form></td>
    <td><form action="get_info_U.php" method="POST">
<button type="submit"> UPDATE</button>
</form></td>
    <td><form action="get_info_D.php" method="POST">
<button type="submit"> DELETE</button>
</form></td>
  </tr>
</table>
<p> Use this box to show current entries</p>

<br />
    
<?php include('showdata.php'); ?>
    <!--
<form>
    <select name="users" onchange="showUser(this.value)">
        <option value="">Select a Farm</option>
        <option value="1">Farm 1</option>
        <option value="2">Cows on Farm 1</option>
        <option value="3">Bulls on Farm 1</option>
        <option value="4">Calves on Farm 1</option>
        <option value="5">Farm 2</option>
        <option value="6">Cows on Farm 2</option>
        <option value="7">Bulls on Farm 2</option>
        <option value="8">Calves on Farm 2</option>
        <option value="9">Farm 3</option>
        <option value="10">Cows on Farm 3</option>
        <option value="11">Bulls on Farm 3</option>
        <option value="12">Calves on Farm 3</option>
        <option value="13">Farm 4</option>
        <option value="14">Cows on Farm 4</option>
        <option value="15">Bulls on Farm 4</option>
        <option value="16">Calves on Farm 4</option>
    </select>
</form>


<br>

<div id="txtHint" style="overflow-y: scroll; height:500px;">Table info will be listed here...</div>

-->
    <form action="home.php">
    <button type="submit">Home</button>
    </form>
    
    
    </Center>
    
</body>

</html>