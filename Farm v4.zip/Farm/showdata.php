<?php
include('dbcreds.php');
?>
  <body>
             
              <br/>
            
            <form>
                <select name="users" onchange="showUser(this.value)">
                    <option value="">Select a Farm</option>
                    <option value="1">Farm 1</option>
                    <option value="2">Cows on Farm 1</option>
                    <option value="3">Bulls on Farm 1</option>
                    <option value="4">Calves on Farm 1</option>
                    <option value="5">Farm 2</option>
                    <option value="6">Cows on Farm 2</option>
                    <option value="7">Bulls on Farm 2</option>
                    <option value="8">Calves on Farm 2</option>
                    <option value="9">Farm 3</option>
                    <option value="10">Cows on Farm 3</option>
                    <option value="11">Bulls on Farm 3</option>
                    <option value="12">Calves on Farm 3</option>
                    <option value="13">Farm 4</option>
                    <option value="14">Cows on Farm 4</option>
                    <option value="15">Bulls on Farm 4</option>
                    <option value="16">Calves on Farm 4</option>
                </select>
            </form>
            
            <div id="txtHint" style="overflow-y: scroll;height:500px;">Table info will be listed here...</div>
            

        <br/>   
        <br/>
</body>
