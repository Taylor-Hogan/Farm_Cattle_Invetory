

<!DOCTYPE html>
<html>
<head>

    
</head>
<body>

<?php
$q = intval($_GET['q']);

    include('dbcreds.php');
    
$con = new mysqli($servername, $username, $password, $dbname);
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}else{
    //echo 'connected successfuly!!';
}

//    WHERE id = '".$q."'
  
//// SOBIE TABLE OPTION (Regsiters)   
    
//mysqli_select_db($con,$q);

    
    // SWITCH FOR EACH DROP DOWN LIST
    
    
switch($q){
        
    case '1':   
//$sql="SELECT * FROM sobie LIMIT 5";
  $sql="SELECT * FROM Farm1";

$result = mysqli_query($con,$sql);
echo" <tableheading> ALL COWS - FARM 1</tableheading> ";


echo "<table>
<tr>
<th>Tagnumber</th>
<th>Type</th>
<th>Has Calf</th>
<th>Calf Number</th>
<th>Number of Calves</th>
<th>Color</th>
<th>Age</th>
<th>Year Purchased</th>

</tr>";
 
while($row = mysqli_fetch_array($result)) {
    
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "<td>" . $row['Has_Calf'] . "</td>";
    echo "<td>" . $row['Calf_Number'] . "</td>";
    echo "<td>" . $row['number_of_calves'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
}
echo "</table>";
    
  break;
        
      
      
//  Farm 1 COWS 
   case '2': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM cows";

$result = mysqli_query($con,$sql);
echo" <tableheading>COWS on FARM 1</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    
    break;
// INQUIRIES TABLE OPTION   (Inquiries)
    
    case '3':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM bulls";

$result = mysqli_query($con,$sql);
echo" <tableheading> Bulls on arm 1</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
         case '4':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM calves";

$result = mysqli_query($con,$sql);
echo" <tableheading> Calves on Farm 1</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
        case '5';
        
        $sql="SELECT * FROM Farm2";

$result = mysqli_query($con,$sql);
echo" <tableheading> ALL COWS - FARM 2 </tableheading> ";


echo "<table>
<tr>
<th>Tagnumber</th>
<th>Type</th>
<th>Has Calf</th>
<th>Calf Number</th>
<th>Number of Calves</th>
<th>Color</th>
<th>Age</th>
<th>Year Purchased</th>

</tr>";
 
while($row = mysqli_fetch_array($result)) {
    
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "<td>" . $row['Has_Calf'] . "</td>";
    echo "<td>" . $row['Calf_Number'] . "</td>";
    echo "<td>" . $row['number_of_calves'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
}
echo "</table>";
    
  break;
        
        case '6': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM cows2";

$result = mysqli_query($con,$sql);
echo" <tableheading> Cows on Farm 2</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    
    break;
    
    case '7':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM bulls2";

$result = mysqli_query($con,$sql);
echo" <tableheading> Bulls on Farm 2</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
         case '8':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM calves2";

$result = mysqli_query($con,$sql);
echo" <tableheading> Calves on Farm 2</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
        
                case '9': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM Farm3";

$result = mysqli_query($con,$sql);
echo" <tableheading> ALL COWS - FARM 3 </tableheading> ";


echo "<table>
<tr>
<th>Tagnumber</th>
<th>Type</th>
<th>Has Calf</th>
<th>Calf Number</th>
<th>Number of Calves</th>
<th>Color</th>
<th>Age</th>
<th>Year Purchased</th>

</tr>";
 
while($row = mysqli_fetch_array($result)) {
    
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "<td>" . $row['Has_Calf'] . "</td>";
    echo "<td>" . $row['Calf_Number'] . "</td>";
    echo "<td>" . $row['number_of_calves'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
}
echo "</table>";
    
    
    break;
    
     case '10': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM cows3";

$result = mysqli_query($con,$sql);
echo" <tableheading> Cows on Farm 3</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    
    break;
    
    case '11':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM bulls3";

$result = mysqli_query($con,$sql);
echo" <tableheading> Bulls on Farm 3</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
         case '12':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM calves3";

$result = mysqli_query($con,$sql);
echo" <tableheading> Calves on Farm 3</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
                       case '13': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM Farm4";

$result = mysqli_query($con,$sql);
echo" <tableheading> ALL COWS - FARM 4 </tableheading> ";


echo "<table>
<tr>
<th>Tagnumber</th>
<th>Type</th>
<th>Has Calf</th>
<th>Calf Number</th>
<th>Number of Calves</th>
<th>Color</th>
<th>Age</th>
<th>Year Purchased</th>

</tr>";
 
while($row = mysqli_fetch_array($result)) {
    
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "<td>" . $row['Has_Calf'] . "</td>";
    echo "<td>" . $row['Calf_Number'] . "</td>";
    echo "<td>" . $row['number_of_calves'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
}
echo "</table>";
    
    break;
    
     case '14': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM cows4";

$result = mysqli_query($con,$sql);
echo" <tableheading> Cows on Farm 4</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    
    break;
    
    case '15':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM bulls4";

$result = mysqli_query($con,$sql);
echo" <tableheading> Bulls on Farm 4</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
         case '16':
           
    mysqli_select_db($con,$q);
$sql="SELECT * FROM calves4";

$result = mysqli_query($con,$sql);
echo" <tableheading> Calves on Farm 4</tableheading> ";
echo "<table>
<tr>

<th>Tagnumber</th>
<th>Color</th>
<th>Age</th>
<th>Purchasedyr</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
   
    break;
        
        
 /** 
      
      BELOW THIS THE THE OTHER TABLE LINKS..
      I CAN ADD THE OTHER FARM LOCATIIONS AS WE GET TO THEM. 
      THIS USES A SWITCH CASE    
    case '4':
// QUICK Contact Information (Quick Contact)
    
mysqli_select_db($con,$q);
$sql = "SELECT first_name,middle_name,last_name,address,city,state,zip,phone,organization,total FROM sobie";;

$result = mysqli_query($con,$sql);
echo" <tableheading> Contact Information </tableheading> ";
echo "<table>
<tr>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Address</th>
<th>City</th>
<th>State</th>
<th>Zip</th>
<th>Phone</th>
<th>Organization</th>
<th>Total</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['first_name'] . "</td>";
    echo "<td>" . $row['middle_name'] . "</td>";
    echo "<td>" . $row['last_name'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "<td>" . $row['city'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['zip'] . "</td>";
    echo "<td>" . $row['phone'] . "</td>";
    echo "<td>" . $row['organization'] . "</td>";
    echo "<td>" ."$". $row['total'] . "</td>";
    echo "</tr>";
}
echo "</table>";

//$sql = " SELECT first_name,middle_name,last_name,address,city,state,zip,phone,organization,total FROM sobie";
break;
 **/        
}
 
        
mysqli_close($con);
        
?>
</body>
</html>