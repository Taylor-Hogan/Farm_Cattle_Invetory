<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// get passed in info
 $tag = $_POST["tagnumber"]; 



//Gets farm selection
$selection = $_POST["farm#"];


switch ($selection) {
   
    case "FARM 1":
//Deletes cow in overall farm database
$sql = "DELETE FROM Farm1 WHERE tagnumber = '$tag' " ;
//Deletes cow in cows table
$sqlc = "DELETE FROM cows WHERE tagnumber = '$tag' " ;
//Deletes cow in bulls table
$sqlb = "DELETE FROM bulls WHERE tagnumber = '$tag' " ;
//Deletes cow in calves table
$sqlv = "DELETE FROM calves WHERE tagnumber = '$tag' " ;

// sql to delete a record
if ($conn->query($sql) === TRUE) {   
    $conn->query($sqlc); 
    $conn->query($sqlb);
    $conn->query($sqlv);     
    echo "Record deleted successfully";	
} else {
    echo "Error deleting record: " . $conn->error;
}
header("Location: home.php");
$conn->close();
        break;
    
    
    
    case "FARM 2":
        //Deletes cow in overall farm database
$sql = "DELETE FROM Farm2 WHERE tagnumber = '$tag' " ;
//Deletes cow in cows table
$sqlc = "DELETE FROM cows2 WHERE tagnumber = '$tag' " ;
//Deletes cow in bulls table
$sqlb = "DELETE FROM bulls2 WHERE tagnumber = '$tag' " ;
//Deletes cow in calves table
$sqlv = "DELETE FROM calves2 WHERE tagnumber = '$tag' " ;

// sql to delete a record
if ($conn->query($sql) === TRUE) {   
    $conn->query($sqlc); 
    $conn->query($sqlb);
    $conn->query($sqlv);     
    echo "Record deleted successfully";	
} else {
    echo "Error deleting record: " . $conn->error;
}
header("Location: home.php");
$conn->close();
        break;
       
    
    
    
    case "FARM 3":
        //Deletes cow in overall farm database
$sql = "DELETE FROM Farm3 WHERE tagnumber = '$tag' " ;
//Deletes cow in cows table
$sqlc = "DELETE FROM cows3 WHERE tagnumber = '$tag' " ;
//Deletes cow in bulls table
$sqlb = "DELETE FROM bulls3 WHERE tagnumber = '$tag' " ;
//Deletes cow in calves table
$sqlv = "DELETE FROM calves3 WHERE tagnumber = '$tag' " ;

// sql to delete a record
if ($conn->query($sql) === TRUE) {   
    $conn->query($sqlc); 
    $conn->query($sqlb);
    $conn->query($sqlv);     
    echo "Record deleted successfully";	
} else {
    echo "Error deleting record: " . $conn->error;
}
header("Location: home.php");
$conn->close();
        break;
   
    
    
    case "FARM 4":
        //Deletes cow in overall farm database
$sql = "DELETE FROM Farm4 WHERE tagnumber = '$tag' " ;
//Deletes cow in cows table
$sqlc = "DELETE FROM cows4 WHERE tagnumber = '$tag' " ;
//Deletes cow in bulls table
$sqlb = "DELETE FROM bulls4 WHERE tagnumber = '$tag' " ;
//Deletes cow in calves table
$sqlv = "DELETE FROM calves4 WHERE tagnumber = '$tag' " ;

// sql to delete a record
if ($conn->query($sql) === TRUE) {   
    $conn->query($sqlc); 
    $conn->query($sqlb);
    $conn->query($sqlv);     
    echo "Record deleted successfully";	
} else {
    echo "Error deleting record: " . $conn->error;
}
header("Location: home.php");
$conn->close();
        break;
}









?>
