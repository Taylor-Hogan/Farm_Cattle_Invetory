<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// get passed in info
 $tag = $_POST["tagnumber"]; 

 $color = $_POST["color"];
 
 $age = $_POST["age"];

 $year = $_POST["purchasedyr"] ;

$cow = $_POST{"type"};

$calf = $_POST{"has_calf"};

$calfNumber = $_POST{"calf_num"};

$Number_of_Calves = $_POST{"number_of_calves"} ;


 $Ntag = $_POST["Ntagnumber"]; 

 $Ncolor = $_POST["Ncolor"];
 
 $Nage = $_POST["Nage"];

 $Nyear = $_POST["Npurchasedyr"] ;

$Ncow = $_POST{"Ntype"};

$Ncalf = $_POST{"Nhas_calf"};

$NcalfNumber = $_POST{"Ncalf_num"};

$NNumber_of_Calves = $_POST{"Nnumber_of_calves"} ;




// sql to delete a record
$sql = "UPDATE cows1 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE cows1 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE cows1 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE cows1 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE cows1 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE cows1 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE cows1 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE cows1 SET number_of_calves = '$Number_of_Calves'  WHERE tagnumber = '$tag'";
#AND color = '$Ncolor' AND age = '$Nage'
# AND purchasedyr = $Nyear 
#AND color = '$color' 
#AND age = '$age' AND purchasedyr = '$year'"; 


#(tagnumber,color,age,purchasedyr) IN (($tag),($color),($age),($year))";

if ($conn->query($sql) === TRUE) {
    echo "Tag Updated successfully";echo"<br>";
	
	if ($conn->query($sql2) === TRUE) {
    echo "Color Updated successfully"; echo"<br>";
	
		if ($conn->query($sql3) === TRUE) {
    echo "Age Updated successfully"; echo"<br>";
	
		if ($conn->query($sql4) === TRUE) {
    echo "Purchased Year Updated successfully";echo"<br>";
        
    	if ($conn->query($sql5) === TRUE) {
    echo " Type Updated successfully";echo"<br>";
            
            if ($conn->query($sql6) === TRUE) {
    echo " Has Calf Updated successfully";echo"<br>";
                
            if ($conn->query($sql7) === TRUE) {
    echo "Calf Number Updated successfully";echo"<br>";
            
            if ($conn->query($sql8) === TRUE) {
    echo "Number of Calves Updated Updated successfully";echo"<br>";
            
            }
            }     
            }
            }
            }
        }
}
}
	else {
    echo "Error updated record: " . $conn->error;
}
#header("Location: home.php");
$conn->close();


?>

<form action="home.php" method="POST">
<button type="submit"> Home</button>
</form>
