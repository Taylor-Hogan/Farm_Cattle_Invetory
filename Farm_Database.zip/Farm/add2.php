<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


 $tag = $_POST["tagnumber"]; 

 $color = $_POST["color"];
 
 $age = $_POST["age"];

 $year = $_POST["purchasedyr"] ;
 

$cow = $_POST{"type"};

$calf = $_POST{"has_calf"};

$calfNumber = $_POST{"calf_num"};

$Number_of_Calves = $_POST{"number_of_calves"} ;


#echo $tag;
 #echo"<br>";
#echo $color;
 #echo"<br>";
#echo $age ;
 #echo"<br>";
#echo $year;
 #echo"<br>";

$sql = "INSERT INTO cows1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";

 if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    # header("Location: home.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
#$conn->close();
$sql1 = "INSERT INTO cows1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";

  /**  THIS IS A TEST LOOP TO POPULATE FARM 1 TABLE WITH 500 ROWS OF DATA
 ****************************************************************************** 
$x = 1; 

do {
    if ($conn->query($sql1) === TRUE) {
    echo "New record created successfully";
     header("Location: home.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
        $conn->close();
}
    $x++;
} while ($x <= 500);

*******************************************************************************
**/
    
    
    

?>