

<!DOCTYPE html>
<html>
<head>

    
</head>
<body>

<?php
$q = intval($_GET['q']);

    include('dbcreds.php');
    
$con = new mysqli($servername, $username, $password, $dbname);
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}else{
    //echo 'connected successfuly!!';
}

//    WHERE id = '".$q."'
  
//// SOBIE TABLE OPTION (Regsiters)   
    
//mysqli_select_db($con,$q);

    
    // SWITCH FOR EACH DROP DOWN LIST
    
    
switch($q){
        
    case '1':   
//$sql="SELECT * FROM sobie LIMIT 5";
  $sql="SELECT * FROM cows1";

$result = mysqli_query($con,$sql);
echo" <tableheading> RESULTS</tableheading> ";


echo "<table>
<tr>
<th>Tagnumber</th>
<th>Type</th>
<th>Has Calf</th>
<th>Calf Number</th>
<th>Number of Calves</th>
<th>Color</th>
<th>Age</th>
<th>Year Purchased</th>

</tr>";
 
while($row = mysqli_fetch_array($result)) {
    
    echo "<tr>";
    echo "<td>" . $row['tagnumber'] . "</td>";
     echo "<td>" . $row['type'] . "</td>";
     echo "<td>" . $row['Has_Calf'] . "</td>";
     echo "<td>" . $row['Calf_Number'] . "</td>";
       echo "<td>" . $row['number_of_calves'] . "</td>";
    echo "<td>" . $row['color'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['purchasedyr'] . "</td>";
}
echo "</table>";
    
  break;
        
      /** 
      
      BELOW THIS THE THE OTHER TABLE LINKS..
      I CAN ADD THE OTHER FARM LOCATIIONS AS WE GET TO THEM. 
      THIS USES A SWITCH CASE 
      
//  EMAIL LIST  TABLE OPTION  (Email List)  
   case '2': 
        
    mysqli_select_db($con,$q);
$sql="SELECT * FROM emaillist";

$result = mysqli_query($con,$sql);
echo" <tableheading> Email List</tableheading> ";
echo "<table>
<tr>

<th>Email</th>

</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    //echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
//    echo "<td>" . $row['Age'] . "</td>";
//    echo "<td>" . $row['Hometown'] . "</td>";
//    echo "<td>" . $row['Job'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    
    break;
// INQUIRIES TABLE OPTION   (Inquiries)
    
    case '3':
    
    mysqli_select_db($con,$q);
$sql="SELECT * FROM inquiries";

$result = mysqli_query($con,$sql);
echo" <tableheading> Inquiries </tableheading> ";
echo "<table>
<tr>
<th> Name </th>
<th> Email </th>
<th> Phone </th>
<th> Subject </th>
<th> Message </th>

</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['Name'] . "</td>";
    echo "<td>" . $row['Email'] . "</td>";
    echo "<td>" . $row['Telephone'] . "</td>";
    echo "<td>" . $row['Subject'] . "</td>";
    echo "<td>" . $row['Message'] . "</td>";
    echo "</tr>";
}
echo "</table>";
    
    break;
    
    case '4':
// QUICK Contact Information (Quick Contact)
    
mysqli_select_db($con,$q);
$sql = "SELECT first_name,middle_name,last_name,address,city,state,zip,phone,organization,total FROM sobie";;

$result = mysqli_query($con,$sql);
echo" <tableheading> Contact Information </tableheading> ";
echo "<table>
<tr>
<th>First Name</th>
<th>Middle Name</th>
<th>Last Name</th>
<th>Address</th>
<th>City</th>
<th>State</th>
<th>Zip</th>
<th>Phone</th>
<th>Organization</th>
<th>Total</th>


</tr>";
    
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['first_name'] . "</td>";
    echo "<td>" . $row['middle_name'] . "</td>";
    echo "<td>" . $row['last_name'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "<td>" . $row['city'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['zip'] . "</td>";
    echo "<td>" . $row['phone'] . "</td>";
    echo "<td>" . $row['organization'] . "</td>";
    echo "<td>" ."$". $row['total'] . "</td>";
    echo "</tr>";
}
echo "</table>";

//$sql = " SELECT first_name,middle_name,last_name,address,city,state,zip,phone,organization,total FROM sobie";
break;
 **/        
}
 
        
mysqli_close($con);
        
?>
</body>
</html>