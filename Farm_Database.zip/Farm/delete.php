<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// get passed in info
 $tag = $_POST["tagnumber"]; 

 $color = $_POST["color"];
 
 $age = $_POST["age"];

 $year = $_POST["purchasedyr"] ;


// sql to delete a record
$sqlall = "DELETE FROM cows1 WHERE tagnumber = '$tag' AND color = '$color' AND age = '$age' AND purchasedyr = $year" ;

$sql = "DELETE FROM cows1 WHERE tagnumber = '$tag' " ;

#(tagnumber,color,age,purchasedyr) IN (($tag),($color),($age),($year))";

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	
} else {
    echo "Error deleting record: " . $conn->error;
}


header("Location: home.php");
$conn->close();
?>
