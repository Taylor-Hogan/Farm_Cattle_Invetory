
<?php
   include('dbcreds.php');
?>


<html>
    
<body>
    
 <head>
<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<script>
            function showUser(str) {
                if (str == "") {
                    document.getElementById("txtHint").innerHTML = "";
                    return;
                } else {
                    if (window.XMLHttpRequest) {
                        // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (this.readyState == 4 && this.status == 200) {
                            document.getElementById("txtHint").innerHTML = this.responseText;
                        }
                    };
                    xmlhttp.open("GET", "getuser.php?q=" + str, true);
                    xmlhttp.send();
                }
            }
        </script>  
   

<center><H1>Hogan's Farm Database</H1></center>
    
<center>
<form action="update.php" method="POST">
<table style= "" >
   <!-- <h3> Enter record to be Updated :</h3> -->
  <tr>
    <th>Cow to be Updated</th>
  </tr>
  <tr>
    <td>Tagnumber: <input type="number" name="tagnumber" required ></td>
  </tr>
 <!--
     <tr>
    <td>Type: <input type="text" name="type"></td>
  </tr>
  <tr>
    <td>Has Calf:(YES or NO) <input type="boolean" name="has_calf"></td>
  </tr>
  <tr>
    <td>Calf Number:(Skip if Bull) <input type="number" name="calf_num"></td>
  </tr>
  <tr>
    <td>Number of Calves: (Skip if Bull) <input type="number" name="number_of_calves"></td>
  </tr>
  <tr>
    <td>Color: <input type="text" name="color" ></td>
  </tr>
  <tr>
    <td>Age: <input type="number" name="age"></td>
  </tr>
  <tr>
    <td>Year Bought/born: <input type="number" name="purchasedyr"></td>
  </tr> -->
  
</table>
<br>
    <table style="">
<!-- <h3> <center>Enter record UPDATED information :</center></h3>-->
  <tr>
    <th> Updated Changes to Cow </th>
  </tr>
  <!-- <tr>
    <td>Tagnumber: <input type="number" name="Ntagnumber" required ></td>
  </tr>-->
  <tr>
    <td>Type: <input type="text" name="Ntype"></td>
  </tr>
  <tr>
    <td>Has Calf:(YES or NO) <input type="boolean" name="Nhas_calf"></td>
  </tr>
  <tr>
    <td>Calf Number:(Skip if Bull) <input type="number" name="Ncalf_num"></td>
  </tr>
  <tr>
    <td>Number of Calves: (Skip if Bull) <input type="number" name="Nnumber_of_calves"></td>
  </tr>
  <tr>
    <td>Color: <input type="text" name="Ncolor" ></td>
  </tr>
  <tr>
    <td>Age: <input type="number" name="Nage"></td>
  </tr>
  <tr>
    <td>Year Bought/born: <input type="number" name="Npurchasedyr"></td>
  </tr>
</table>
    <br>
 <td><input type="submit" value="SUBMIT" ></td>   
<!--
    Tagnumber: <input type="number" name="Ntagnumber" required ><br>

    Color: <input type="text" name="Ncolor"  ><br>

    Age: <input type="number" name="Nage" ><br>

    Year Bought: <input type="number" name="Npurchasedyr" ><br>

    Type: <input type="text" name="Ntype" ><br>

    Has Calf:(YES or NO) <input type="boolean" name="Nhas_calf"><br>

    Calf Number:(Skip if Bull) <input type="number" name="Ncalf_num"><br>
  
    Number of Calves: (Skip if Bull) <input type="number" name="Nnumber_of_calves"><br>
    
    
<input type="submit">
    
 -->
    </form>
    
 
   <br>
   
    
    
   
    <form action="home.php">
    <input type="submit" value="HOME" />
</form>
    </center>
<br>

<center>
<h3>  Select Farm below to View Current Cows</h3>
             
              <br/>
            
            <form>
                <select name="users" onchange="showUser(this.value)">
                    <option value="">Select a Farm</option>
                    <option value="1">Farm 1</option>
                    <option value="2">Farm 2</option>
                    <option value="3">Farm 3</option>
                    <option value="4">Farm 4</option>
                </select>
            </form>
               
            <br>
            
            <div id="txtHint" style="overflow-y: scroll; height:500px;">Table info will be listed here...</div>
            

        <br/>   
        <br/>
</center>
</body>
</html>
