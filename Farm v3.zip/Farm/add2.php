<?php
session_start();

include('dbcreds.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// gets vars from POST
$tag              = $_POST["tagnumber"];
$color            = $_POST["color"];
$age              = $_POST["age"];
$year             = $_POST["purchasedyr"];
$cow              = $_POST{"type"};
$calf             = $_POST{"has_calf"};
$calfNumber       = $_POST{"calf_num"};
$Number_of_Calves = $_POST{"number_of_calves"};


//Gets farm selection
$selection = $_POST["farm#"];

switch ($selection) {
    case "FARM 1":
        echo "selection is farm 1!";
        
        switch ($cow) {
            case "COW":
                $cowa = "INSERT INTO cows (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                  
                $sql1 = "INSERT INTO farm1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                
                if ($conn->query($cowa) === TRUE) {
                    $conn->query($sql1);
                    echo "New record created successfully";
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            
            case "BULL":
                $bulla = "INSERT INTO bulls (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
               $sql1 = "INSERT INTO farm1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')"; 
                if ($conn->query($bulla) === TRUE) {
                    $conn->query($sql1);
                   echo "New record created successfully"; 
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            case "CALF":
                $calfa = "INSERT INTO calves (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                $sql1 = "INSERT INTO farm1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                
                if ($conn->query($calfa) === TRUE) {
                    $conn->query($sql1);
                    echo "New record created successfully";
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            default:
                
                echo "wrong selection";
        }
        
        break;
    
    
    
    
    
    
    
    case "FARM 2":
        echo "selection is farm 2!";
        
        switch ($cow) {
            case "COW":
                $cowa = "INSERT INTO cows2 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
              $sql1 = "INSERT INTO farm2 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";  
                if ($conn->query($cowa) === TRUE) {
                    $conn->query($sql1);
                    echo "New record created successfully";
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            
            case "BULL":
                $bulla = "INSERT INTO bulls2 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                $sql1 = "INSERT INTO farm2 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                if ($conn->query($bulla) === TRUE) {
                    $conn->query($sql1);
                    
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            case "CALF":
                $calfa = "INSERT INTO calves2 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                $sql1 = "INSERT INTO farm2 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                
                if ($conn->query($calfa) === TRUE) {
                    $conn->query($sql1);
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            default:
                
                echo "wrong selection";
        }
        
        break;
    
    
    
    
    
    case "FARM 3":
        echo "selection is farm 3!";
        
        switch ($cow) {
            case "COW":
                $cowa = "INSERT INTO cows3 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                $sql1 = "INSERT INTO farm3 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                if ($conn->query($cowa) === TRUE) {
                    $conn->query($sql1);
                    echo "New record created successfully";
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            
            case "BULL":
                $bulla = "INSERT INTO bulls3 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                $sql1 = "INSERT INTO farm3 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                if ($conn->query($bulla) === TRUE) {
                    $conn->query($sql1);
                    
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            case "CALF":
                $calfa = "INSERT INTO calves3 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
               $sql1 = "INSERT INTO farm3 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')"; 
                
                if ($conn->query($calfa) === TRUE) {
                    $conn->query($sql1);
                    header("Location: home.php");
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                break;
            
            }
        
        break;
            
            
            case "FARM 4":
                echo "selection is farm 4!";
                
                switch ($cow) {
                    case "COW":
                        $cowa = "INSERT INTO cows4 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                        $sql1 = "INSERT INTO farm4 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                        if ($conn->query($cowa) === TRUE) {
                            $conn->query($sql1);
                            echo "New record created successfully";
                            header("Location: home.php");
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                        break;
                    
                    case "BULL":
                        $bulla = "INSERT INTO bulls4 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                        $sql1 = "INSERT INTO farm4 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                        if ($conn->query($bulla) === TRUE) {
                            $conn->query($sql1);
                            
                            header("Location: home.php");
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                        break;
                    case "CALF":
                        $calfa = "INSERT INTO calves4 (tagnumber, color, age,purchasedyr)
VALUES ('$tag', '$color', '$age','$year')";
                        $sql1 = "INSERT INTO farm4 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
                        if ($conn->query($calfa) === TRUE) {
                        $conn->query($sql1) ;
                            echo "New record created successfully";
                            header("Location: home.php"); 
                        }else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                        break;
                    
                }
                   break;
                
        }
        
        
        /** 
        
        *********************dead queries *************************************
        $sql1 = "INSERT INTO farm1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
        
        **************************************************************************
        $sql = "INSERT INTO cows1 (tagnumber, color, age,purchasedyr,type ,Has_Calf,Calf_Number,number_of_calves)
        VALUES ('$tag', '$color', '$age','$year','$cow', '$calf', '$calfNumber', '$Number_of_Calves')";
        ***************************************************************************     
        
        
        
        
        if (isset($_POST['type'])) {
        $cowa = "INSERT INTO cows (tagnumber, color, age,purchasedyr)
        VALUES ('$tag', '$color', '$age','$year')";
        //header("Location: http://www.google.com/");
        
        if ($conn->query($cowa) === TRUE) {
        
        echo "New record created successfully";
        //header("Location: home.php");
        
        } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        }
        } 
        
        else
        
        //if ($conn->query($sql) === TRUE) {
        
        echo "bad entry";
        //header("Location: home.php");
        
        //} else {
        // echo "Error: " . $sql . "<br>" . $conn->error;
        //}
        
        **/
        
        
        #$conn->close();
        
        
        /**  THIS IS A TEST LOOP TO POPULATE FARM 1 TABLE WITH 500 ROWS OF DATA
         *******************************************************************************
         $x = 1; 
         
         do {
         if ($conn->query($sql1) === TRUE) {
         echo "New record created successfully";
         header("Location: home.php");
         } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
         $conn->close();
         }
         $x++;
         } while ($x <= 2);
         
         /**
         *******************************************************************************
         **/
        



?>