
<?php
   include('dbcreds.php');
?>


<html>
    
   
    
<body>
 <head>
<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<script>
            function showUser(str) {
                if (str == "") {
                    document.getElementById("txtHint").innerHTML = "";
                    return;
                } else {
                    if (window.XMLHttpRequest) {
                        // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (this.readyState == 4 && this.status == 200) {
                            document.getElementById("txtHint").innerHTML = this.responseText;
                        }
                    };
                    xmlhttp.open("GET", "getuser.php?q=" + str, true);
                    xmlhttp.send();
                }
            }
        </script>  
   
    <CENTER>
        <H1>Hogan's Farm Database</H1> 
    <form action="delete.php" method="POST">
<h3> Select Farm to make changes</h3>
<table>
  <tr>
    <th>Select Farm</th>
  </tr>
  <tr>
    <td>Farm Number: <select name="farm#" required>
  <option  value="" >SELECT A FARM </option>  
  <option value="FARM 1" >FARM 1</option>
  <option value="FARM 2" >FARM 2</option>
  <option value="FARM 3" >FARM 3</option>  
  <option value="FARM 4" >FARM 4</option>  
</select>
      </td>
  </tr>
  
 </table>
         <br>
<h3> Enter record to be Deleted :</h3>
<table>
  <tr>
    <th>Delete/Sale A COW</th>
  </tr>
  <tr>
    <td>Tagnumber: <input type="number" name="tagnumber" required ></td>
  </tr>
  
 </table>
         <br>
    <td><input type="submit"></td>
</form>

<form action="home.php">
    <input type="submit" value="HOME" />
</form>

   <h3>  Select Farm below to View Current Cows</h3>
             
              <br/>
            
             <form>
                <select name="users" onchange="showUser(this.value)">
                    <option value="">Select a Farm</option>
                    <option value="1">Farm 1</option>
                    <option value="2">Cows on Farm 1</option>
                    <option value="3">Bulls on Farm 1</option>
                    <option value="4">Calves on Farm 1</option>
                    <option value="5">Farm 2</option>
                    <option value="6">Farm 3</option>
                    <option value="7">Farm 4</option>
                </select>
            </form>
            <br>
            
            <div id="txtHint" style="overflow-y: scroll; height:500px;">Table info will be listed here...</div>
            

        <br/>   
        <br/>
</CENTER>

</body>
</html>
