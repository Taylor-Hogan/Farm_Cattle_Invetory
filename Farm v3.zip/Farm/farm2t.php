<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


 $tag = $_POST["tagnumber"]; 

 $color = $_POST["color"];
 
 $age = $_POST["age"];

 $year = $_POST["purchasedyr"] ;
 

$cow = $_POST{"type"};

$calf = $_POST{"has_calf"};

$calfNumber = $_POST{"calf_num"};

$Number_of_Calves = $_POST{"number_of_calves"} ;

 //print_r($_POST);
   var_dump($_POST);

?>