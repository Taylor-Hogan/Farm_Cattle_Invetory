<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// get passed in info
 $tag = $_POST["tagnumber"]; 

 $color = $_POST["color"];
 
 $age = $_POST["age"];

 $year = $_POST["purchasedyr"] ;

$cow = $_POST{"type"};

$calf = $_POST{"has_calf"};

$calfNumber = $_POST{"calf_num"};

$Number_of_Calves = $_POST{"number_of_calves"} ;


 $Ntag = $_POST["Ntagnumber"]; 

 $Ncolor = $_POST["Ncolor"];
 
 $Nage = $_POST["Nage"];

 $Nyear = $_POST["Npurchasedyr"] ;

$Ncow = $_POST{"Ntype"};

$Ncalf = $_POST{"Nhas_calf"};

$NcalfNumber = $_POST{"Ncalf_num"};

$NNumber_of_Calves = $_POST{"Nnumber_of_calves"} ;




// sql quires to UPDATE RECORD ON MAIN OVERALL FARM 
$sql = "UPDATE Farm1 SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2 = "UPDATE Farm1 SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3 = "UPDATE Farm1 SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4 = "UPDATE Farm1 SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5 = "UPDATE Farm1 SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6 = "UPDATE Farm1 SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7 = "UPDATE Farm1 SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8 = "UPDATE Farm1 SET number_of_calves = '$Number_of_Calves'  WHERE tagnumber = '$tag'";
#AND color = '$Ncolor' AND age = '$Nage'
# AND purchasedyr = $Nyear 
#AND color = '$color' 
#AND age = '$age' AND purchasedyr = '$year'"; 

 # Queries to update individual tables.
    
    # update farm 1 cows table
$sqlc = "UPDATE cows SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1c = "UPDATE cows SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2c = "UPDATE cows SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3c = "UPDATE cows SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4c = "UPDATE cows SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5c = "UPDATE cows SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6c = "UPDATE cows SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7c = "UPDATE cows SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8c = "UPDATE Farm1 SET number_of_calves = '$Number_of_Calves'  WHERE tagnumber = '$tag'";
    # update farm 1 bulls table
$sqlb = "UPDATE bulls SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1b = "UPDATE bulls SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2b = "UPDATE bulls SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3b = "UPDATE bulls SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4b = "UPDATE bulls SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5b = "UPDATE bulls SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6b = "UPDATE bulls SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7b = "UPDATE bulls SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8b = "UPDATE bulls SET number_of_calves = '$Number_of_Calves'  WHERE tagnumber = '$tag'";
    # update farm 1 calves table
$sqlv = "UPDATE calves SET tagnumber = '$Ntag'  WHERE tagnumber = '$tag' ";
$sql1v = "UPDATE calves SET type = '$Ncow'  WHERE tagnumber = '$tag' ";
$sql2v = "UPDATE calves SET color = '$Ncolor'  WHERE tagnumber = '$tag'";
$sql3v = "UPDATE calves SET age = '$Nage'  WHERE tagnumber = '$tag'";
$sql4v = "UPDATE calves SET purchasedyr = '$Nyear' WHERE tagnumber = '$tag'";
$sql5v = "UPDATE calves SET type = '$Ncow'  WHERE tagnumber = '$tag'";
$sql6v = "UPDATE calves SET Has_calf = '$Ncalf'  WHERE tagnumber = '$tag'";
$sql7v = "UPDATE calves SET Calf_Number = '$NcalfNumber'  WHERE tagnumber = '$tag'";
$sql8v = "UPDATE calves SET number_of_calves = '$Number_of_Calves'  WHERE tagnumber = '$tag'";

# Runs Queries to update main tables. 
if ($conn->query($sql) === TRUE) {
    header("Location: home.php");
    echo "Tag Updated successfully";echo"<br>";
	
    if ($conn->query($sql1) === TRUE) {
    echo "Type Updated successfully"; echo"<br>";
        
	if ($conn->query($sql2) === TRUE) {
    echo "Color Updated successfully"; echo"<br>";
	
		if ($conn->query($sql3) === TRUE) {
    echo "Age Updated successfully"; echo"<br>";
	
		if ($conn->query($sql4) === TRUE) {
    echo "Purchased Year Updated successfully";echo"<br>";
        
    	if ($conn->query($sql5) === TRUE) {
    echo " Type Updated successfully";echo"<br>";
            
            if ($conn->query($sql6) === TRUE) {
    echo " Has Calf Updated successfully";echo"<br>";
                
            if ($conn->query($sql7) === TRUE) {
    echo "Calf Number Updated successfully";echo"<br>";
            
            if ($conn->query($sql8) === TRUE) {
    echo "Number of Calves Updated Updated successfully";echo"<br>";
            
            }
            }     
            }
            }
            }
        }
}
}
}
	else {
    echo "Error updated record: " . $conn->error;
}
    
    # Runs Queries to update individual tables.
    
    # update farm 1 cows table
    if ($conn->query($sqlc) === TRUE) {
    header("Location: home.php");
    echo "Tag Updated successfully";echo"<br>";
	
    if ($conn->query($sql1c) === TRUE) {
    echo "Type Updated successfully"; echo"<br>";
        
	if ($conn->query($sql2c) === TRUE) {
    echo "Color Updated successfully"; echo"<br>";
	
		if ($conn->query($sql3c) === TRUE) {
    echo "Age Updated successfully"; echo"<br>";
	
		if ($conn->query($sql4c) === TRUE) {
    echo "Purchased Year Updated successfully";echo"<br>";
        
    	if ($conn->query($sql5c) === TRUE) {
    echo " Type Updated successfully";echo"<br>";
            
            if ($conn->query($sql6c) === TRUE) {
    echo " Has Calf Updated successfully";echo"<br>";
                
            if ($conn->query($sql7c) === TRUE) {
    echo "Calf Number Updated successfully";echo"<br>";
            
            if ($conn->query($sql8c) === TRUE) {
    echo "Number of Calves Updated Updated successfully";echo"<br>";
            
            }
            }     
            }
            }
            }
        }
}
}
    }
	else {
    echo "Error updated record: " . $conn->error;
}
    # update farm 1 bulls table
if ($conn->query($sqlb) === TRUE) {
    header("Location: home.php");
    echo "Tag Updated successfully";echo"<br>";
	
    if ($conn->query($sql1b) === TRUE) {
    echo "Type Updated successfully"; echo"<br>";
        
	if ($conn->query($sql2b) === TRUE) {
    echo "Color Updated successfully"; echo"<br>";
	
		if ($conn->query($sql3b) === TRUE) {
    echo "Age Updated successfully"; echo"<br>";
	
		if ($conn->query($sql4b) === TRUE) {
    echo "Purchased Year Updated successfully";echo"<br>";
        
    	if ($conn->query($sql5b) === TRUE) {
    echo " Type Updated successfully";echo"<br>";
            
            if ($conn->query($sql6b) === TRUE) {
    echo " Has Calf Updated successfully";echo"<br>";
                
            if ($conn->query($sql7b) === TRUE) {
    echo "Calf Number Updated successfully";echo"<br>";
            
            if ($conn->query($sql8b) === TRUE) {
    echo "Number of Calves Updated Updated successfully";echo"<br>";
            
            }
            }     
            }
            }
            }
        }
}
}
}
	else {
    echo "Error updated record: " . $conn->error;
}
    # update farm 1 calves table
    
    if ($conn->query($sqlv) === TRUE) {
    header("Location: home.php");
    echo "Tag Updated successfully";echo"<br>";
	
    if ($conn->query($sql1v) === TRUE) {
    echo "Type Updated successfully"; echo"<br>";
        
	if ($conn->query($sql2v) === TRUE) {
    echo "Color Updated successfully"; echo"<br>";
	
		if ($conn->query($sql3v) === TRUE) {
    echo "Age Updated successfully"; echo"<br>";
	
		if ($conn->query($sql4v) === TRUE) {
    echo "Purchased Year Updated successfully";echo"<br>";
        
    	if ($conn->query($sql5v) === TRUE) {
    echo " Type Updated successfully";echo"<br>";
            
            if ($conn->query($sql6v) === TRUE) {
    echo " Has Calf Updated successfully";echo"<br>";
                
            if ($conn->query($sql7v) === TRUE) {
    echo "Calf Number Updated successfully";echo"<br>";
            
            if ($conn->query($sql8v) === TRUE) {
    echo "Number of Calves Updated Updated successfully";echo"<br>";
            
            }
            }     
            }
            }
            }
        }
}
}
    }
	else {
    echo "Error updated record: " . $conn->error;
}
    
#header("Location: home.php");
$conn->close();


?>

<form action="home.php" method="POST">
<button type="submit"> Home</button>
</form>

